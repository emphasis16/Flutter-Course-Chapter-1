import 'package:intl/intl.dart';

/// Date formatter to be used in the app.
final kDateFormatter = DateFormat.MMMEd();
